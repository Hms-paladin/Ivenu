import React from 'react';
import './popupbox.css';
// import Star from '../../starone.png';


export default class Popupbox extends React.Component {

	constructor(props) {
		super(props);

		this.state = {popup_position:{top:0,left:0},open:false};

	}
  toggleFunction=(e)=>{

    let offsetTop  = e.currentTarget.offsetTop+38;
    let offsetLeft  = e.currentTarget.offsetLeft;
    let offsetWidth  = this.instance.getBoundingClientRect().width;
    let height  = this.instance.getBoundingClientRect().height;
    this.setState({popup_position:{top:offsetTop,left:offsetLeft,width:offsetWidth }});
    if(this.props.dropdown){
    this.setState({open:!this.state.open});
}
  }


	render() {
		return (
		<div>
      <button ref={(el) => this.instance = el } className="dropdown-btn" style={{display:"",backgroundColor:this.props.buttonColor,color:this.props.buttonTextColor,width:this.props.buttonText==""?this.props.width:null,height:this.props.height?this.props.height:null}} onClick={this.toggleFunction}>{this.props.buttonText}
      <i class="fa fa-angle-down down-arrow-i popupbox-icon" aria-hidden="true"></i></button>


			{this.state.open&&
			<div class="Popupbox-div-position" style={{position:'absolute',top:this.state.popup_position.top,left:this.state.popup_position.left,minWidth:this.state.popup_position.width}}>

		
			
			<div class="popupbox-div">

			<ul class="dropdown-popup-ul" >
				{this.props.dropdown.dropdown.map((obj,key)=>{
					return(
						<li className={`${key==this.props.dropdown.dropdown.length-1?'li-border-remove':''}`}>{obj[this.props.dropdown.name]}</li>
						)
				})}
			</ul>

			</div>



			</div>
		}
			</div>
			);
	}
}
