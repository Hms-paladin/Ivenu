import React, {Component} from 'react';
import ReactDOM from 'react-dom';

const dropvalue= [{key:1,value:'play'},{key:2,value:'scrosssdxcv'},{key:3,value:'full'},{key:1,value:'play'},{key:2,value:'scross'},{key:3,value:'full'}];

class DropDown extends Component{
	constructor(props) {
		super(props);
		this.handleClick = this.handleClick.bind(this);
		this.handleOutsideClick = this.handleOutsideClick.bind(this);

		this.state = {

			popupVisible: false,
			placeholder:'play'
		};
	}



	handleClick() {

		if (!this.state.popupVisible) {
			document.addEventListener('click', this.handleOutsideClick, false);
		} else {
			document.removeEventListener('click', this.handleOutsideClick, false);
		}

		this.setState(prevState => ({
			popupVisible: !prevState.popupVisible,
		}));
	}

	handleOutsideClick(e) {
		console.log("1")
		if (this.node.contains(e.target)) {
			return;
		}

		this.handleClick();
	}

	OptionClick(key,text){

		console.log(key +" "+text);
		this.handleClick();
		this.setState({placeholder:text})

	}


	render(){

		return(
			<div>

			<div className="drop_select" onClick={this.handleClick}>

			<div className="drop_head">
			<div className="drop_place">	{this.state.placeholder} </div>

			<div className='drop_arrow'> > </div>

			</div> 
			
			</div>
			<div style={{'width':'auto','height':'auto' ,position:'absolute' }} ref={node => { this.node = node; }}>

			{this.state.popupVisible && 
				<div className="drop_main" >
				{dropvalue.map((item,i) => 
					
					<div className="drop_option" onClick={(e)=>this.OptionClick(item.key,item.value)}>
					{item.value}
					</div>
					
					
					)}


				</div>

			}

			</div>
			</div>
			)
	}


}

export default DropDown;